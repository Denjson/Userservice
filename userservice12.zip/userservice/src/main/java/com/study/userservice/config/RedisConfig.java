package com.study.userservice.config;

// @Configuration
// @EnableRedisRepositories(basePackages = "com.study.userservice.repository")
public class RedisConfig {

  //  @Bean
  //  public RedisConnectionFactory redisConnectionFactory() {
  // Configure your Redis connection factory (e.g., using Lettuce or Jedis)
  // This example uses LettuceConnectionFactory for simplicity
  //    return new LettuceConnectionFactory();
  //  }
  //
  //  @Bean
  //  public RedisTemplate<?, ?> redisTemplate() {
  //    RedisTemplate<byte[], byte[]> template = new RedisTemplate<>();
  //    template.setConnectionFactory(redisConnectionFactory());
  //    return template;
  //  }
}
